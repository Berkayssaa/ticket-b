# Woolexa-Saglam-Ticket

Woolexa tarafından kodlanmıştır. Aris Lesnar'a teşekkür ederim yardımları için

# Bot Nasıl Çalıştırılır
Öncelikle npm i yapıyorsunuz
ardından node .
